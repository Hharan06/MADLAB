// In pubspec.yaml
// dependencies:
//   flutter:
//     sdk: flutter
//   firebase_core:
//   firebase_auth:
//   cloud_firestore:

// flutter pub get

// npm install -g firebase-tools

// Login firebase in website with mail id and create a project and create a android app and download the json file and move it to android/app and also create a database in console

// Change the rules in firestore database from false to true

// In cmd
// firebase login

// dart pub global activate flutterfire_cli

// Add C:\Users\harir\AppData\Local\Pub\Cache\bin in System PATH

// flutterfire configure   // this will create firebase_options.dart file

// choose the project and platform  

// add this in main.dart

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutterapp/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform); // Initialize Firebase
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Firestore Example',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: UserListPage(),
    );
  }
}

class UserListPage extends StatelessWidget {
  final CollectionReference users =
      FirebaseFirestore.instance.collection('users');

  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();

  // 🔹 CREATE
  Future<void> addUser(String name, int age) async {
    await users.add({'name': name, 'age': age});
  }

  // 🔹 UPDATE
  Future<void> updateUser(String id, String newName) async {
    await users.doc(id).update({'name': newName});
  }

  // 🔹 DELETE
  Future<void> deleteUser(String id) async {
    await users.doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Simple CRUD')),
      body: Column(
        children: [
          // 🔸 Input Fields
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                    child: TextField(
                        controller: nameController,
                        decoration: InputDecoration(labelText: 'Name'))),
                SizedBox(width: 10),
                Expanded(
                    child: TextField(
                        controller: ageController,
                        decoration: InputDecoration(labelText: 'Age'),
                        keyboardType: TextInputType.number)),
                ElevatedButton(
                  onPressed: () {
                    String name = nameController.text;
                    int age = int.tryParse(ageController.text) ?? 0;
                    if (name.isNotEmpty) {
                      addUser(name, age);
                      nameController.clear();
                      ageController.clear();
                    }
                  },
                  child: Text('Add'),
                )
              ],
            ),
          ),
          // 🔸 Read & Display
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: users.snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return CircularProgressIndicator();
                final docs = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    var data = docs[index].data() as Map<String, dynamic>;
                    String id = docs[index].id;
                    String name = data['name'] ?? 'No name';
                    int age = data['age'] ?? 0;

                    return ListTile(
                      title: Text('Name: $name'),
                      subtitle: Text('Age: $age'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.green),
                            onPressed: () {
                              updateUser(id, '${name}_updated');
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              deleteUser(id);
                            },
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
