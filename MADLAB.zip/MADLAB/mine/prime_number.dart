import 'package:flutter/material.dart';

void main() {
  runApp(PrimeCheckerApp());
}

class PrimeCheckerApp extends StatelessWidget {
  const PrimeCheckerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Prime Number Checker',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: PrimeChecker(),
    );
  }
}

class PrimeChecker extends StatefulWidget {
  const PrimeChecker({super.key});

  @override
  _PrimeCheckerState createState() => _PrimeCheckerState();
}

class _PrimeCheckerState extends State<PrimeChecker> {
  final TextEditingController _numberController = TextEditingController();
  String _result = "";

  void _checkPrime() {
    setState(() {
      int? number = int.tryParse(_numberController.text);
      if (number == null || number < 2) {
        _result = "Invalid or Not a Prime Number";
        return;
      }
      for (int i = 2; i * i <= number; i++) {
        if (number % i == 0) {
          _result = "$number is Not a Prime Number";
          return;
        }
      }
      _result = "$number is a Prime Number";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Prime Number Checker'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _numberController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter a Number',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _checkPrime,
              child: Text('Check Prime'),
            ),
            SizedBox(height: 16),
            Text(
              _result,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
