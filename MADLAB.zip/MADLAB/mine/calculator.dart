import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const CalculatorView(),
    );
  }
}

class CalculatorView extends StatefulWidget {
  const CalculatorView({Key? key}) : super(key: key);

  @override
  State<CalculatorView> createState() => _CalculatorViewState();
}

class _CalculatorViewState extends State<CalculatorView> {
  String equation = "0";
  String result = "0";

  void buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == "AC") {
        equation = "0";
        result = "0";
      } else if (buttonText == "⌫") {
        equation = equation.length > 1
            ? equation.substring(0, equation.length - 1)
            : "0";
      } else if (buttonText == "=") {
        try {
          Parser p = Parser();
          Expression exp =
              p.parse(equation.replaceAll('×', '*').replaceAll('÷', '/'));
          result = exp.evaluate(EvaluationType.REAL, ContextModel()).toString();
        } catch (e) {
          result = "Error";
        }
      } else {
        equation = (equation == "0") ? buttonText : equation + buttonText;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end, // Aligns text to the right
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(result,
                  style: const TextStyle(fontSize: 40, color: Colors.white)),
              Text(equation,
                  style: const TextStyle(fontSize: 25, color: Colors.white54)),
            ],
          ),
          const SizedBox(height: 20),
          buildButtonRow(["AC", "⌫", "÷", "×"]),
          buildButtonRow(["7", "8", "9", "-"]),
          buildButtonRow(["4", "5", "6", "+"]),
          buildButtonRow(["1", "2", "3", "."]),
          buildButtonRow(["0", "00", "+/-", "="]),
        ],
      ),
    );
  }

  Widget buildButtonRow(List<String> buttons) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: buttons
          .map((text) => ElevatedButton(
                onPressed: () => buttonPressed(text),
                child: Text(text),
              ))
          .toList(),
    );
  }
}
