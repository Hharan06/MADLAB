import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For date formatting

void main() {
  runApp(VaccinationApp());
}

class VaccinationApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: VaccinationDatePage(),
    );
  }
}

class VaccinationDatePage extends StatefulWidget {
  @override
  _VaccinationDatePageState createState() => _VaccinationDatePageState();
}

class _VaccinationDatePageState extends State<VaccinationDatePage> {
  DateTime? _vaccinationDate;
  int? _daysRemaining;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(), // Prevent past dates
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _vaccinationDate) {
      setState(() {
        _vaccinationDate = picked;
        _daysRemaining = picked.difference(DateTime.now()).inDays;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    String formattedDate = _vaccinationDate != null
        ? DateFormat('yyyy-MM-dd').format(_vaccinationDate!)
        : 'Select Date';

    return Scaffold(
      appBar: AppBar(
        title: Text('Vaccination Scheduler'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              ElevatedButton(
                onPressed: () => _selectDate(context),
                child: Text(formattedDate),
              ),
              SizedBox(height: 20),
              if (_daysRemaining != null)
                Text(
                  'Days remaining: $_daysRemaining',
                  style: TextStyle(fontSize: 18),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
