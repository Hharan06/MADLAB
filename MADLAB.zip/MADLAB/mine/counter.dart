import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Counters",
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: Counters(),
    );
  }
}

class Counters extends StatefulWidget {
  const Counters({super.key});

  @override
  State<Counters> createState() => _CountersState();
}

class _CountersState extends State<Counters> {
  int _counter = 0;
  int _base = 10;

  void incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  String getCounterValue() {
    switch (_base) {
      case 2:
        return _counter.toRadixString(2).toUpperCase();
      case 8:
        return _counter.toRadixString(8).toUpperCase();
      case 16:
        return _counter.toRadixString(16).toUpperCase();
      default:
        return '$_counter';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Counters"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text("Counter value ($_base): ${getCounterValue()}"),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _base = 10;
                    });
                  },
                  child: Text("Decimal")),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _base = 2;
                    });
                  },
                  child: Text("Binary")),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _base = 8;
                    });
                  },
                  child: Text("Octal")),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _base = 16;
                    });
                  },
                  child: Text("Hexadecimal")),
            ],
          ),
          FloatingActionButton(
            onPressed: incrementCounter,
            child: Icon(Icons.add),
          ),
        ],
      ),
    );
  }
}
