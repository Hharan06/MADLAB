import 'package:flutter/material.dart';

void main() {
  runApp(CalorieCalculatorApp());
}

class CalorieCalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CalorieScreen(),
    );
  }
}

class CalorieScreen extends StatefulWidget {
  @override
  _CalorieScreenState createState() => _CalorieScreenState();
}

class _CalorieScreenState extends State<CalorieScreen> {
  final TextEditingController ageController = TextEditingController();
  final TextEditingController weightController = TextEditingController();
  final TextEditingController heightController = TextEditingController();
  double result = 0.0;
  String selectedGender = "Male";
  String selectedActivity = "Sedentary";
  String userInputs = "";

  void calculateCalories() {
    int? age = int.tryParse(ageController.text);
    double? weight = double.tryParse(weightController.text);
    double? height = double.tryParse(heightController.text);

    if (age == null || weight == null || height == null) {
      setState(() {
        userInputs = "Please enter valid inputs!";
        result = 0.0;
      });
      return;
    }

    // Print user inputs
    userInputs =
        "Age: $age\nWeight: ${weight}kg\nHeight: ${height}cm\nGender: $selectedGender\nActivity Level: $selectedActivity";

    // Mifflin-St Jeor Equation
    double bmr;
    if (selectedGender == "Male") {
      bmr = 88.36 + (13.4 * weight) + (4.8 * height) - (5.7 * age);
    } else {
      bmr = 447.6 + (9.2 * weight) + (3.1 * height) - (4.3 * age);
    }

    double activityFactor;
    switch (selectedActivity) {
      case "Sedentary":
        activityFactor = 1.2;
        break;
      case "Lightly active":
        activityFactor = 1.375;
        break;
      case "Moderately active":
        activityFactor = 1.55;
        break;
      case "Very active":
        activityFactor = 1.725;
        break;
      default:
        activityFactor = 1.2;
    }

    setState(() {
      result = bmr * activityFactor;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Calorie Calculator"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: ageController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter Age"),
            ),
            TextField(
              controller: weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter Weight (kg)"),
            ),
            TextField(
              controller: heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter Height (cm)"),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Gender:"),
                DropdownButton<String>(
                  value: selectedGender,
                  items: ["Male", "Female"]
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedGender = value!;
                    });
                  },
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Activity Level:"),
                DropdownButton<String>(
                  value: selectedActivity,
                  items: [
                    "Sedentary",
                    "Lightly active",
                    "Moderately active",
                    "Very active"
                  ]
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedActivity = value!;
                    });
                  },
                ),
              ],
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: calculateCalories,
              child: Text("Calculate"),
            ),
            SizedBox(height: 20),
            Text(
              userInputs,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 10),
            Text(
              "Daily Calorie Requirement: ${result.toStringAsFixed(2)} kcal",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
