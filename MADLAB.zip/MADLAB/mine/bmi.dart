import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "BMI",
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: BMI(),
    );
  }
}

class BMI extends StatefulWidget {
  const BMI({super.key});

  @override
  State<BMI> createState() => _BMIState();
}

class _BMIState extends State<BMI> {
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  String _selectedGender = "Male";
  String userInputs = "";
  double result = 0;

  void calculateBMI() {
    setState(() {
      double? weight = double.tryParse(_weightController.text);
      double? height = double.tryParse(_heightController.text);

      userInputs = "Weight: $weight, Height: $height, Gender: $_selectedGender";

      int valuebasedongender = 1;

      switch (_selectedGender) {
        case "Male":
          valuebasedongender = 100;
          break;
        case "Female":
          valuebasedongender = 150;
          break;
        default:
          valuebasedongender = 1;
      }

      result = (weight! / pow(height!, 2)) * valuebasedongender;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: _weightController,
            decoration: InputDecoration(
              labelText: "Enter weight",
            ),
          ),
          SizedBox(
            height: 10,
          ),
          TextField(
            decoration: InputDecoration(
              labelText: "Enter height",
            ),
            controller: _heightController,
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Gender:"),
              DropdownButton(
                  value: _selectedGender,
                  items: ["Male", "Female"]
                      .map((e) => DropdownMenuItem(
                            child: Text(e),
                            value: e,
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedGender = value!;
                    });
                  }),
            ],
          ),
          ElevatedButton(onPressed: calculateBMI, child: Text("Calculate")),
          Text(userInputs),
          Text("BMI: $result"),
        ],
      ),
    );
  }
}
