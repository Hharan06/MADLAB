// Install this dependencies
// flutter_map: ^6.2.1
// latlong2: ^0.9.0
// http: ^1.3.0

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hotel Finder (Mock)',
      home: HotelFinderScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HotelFinderScreen extends StatefulWidget {
  @override
  _HotelFinderScreenState createState() => _HotelFinderScreenState();
}

class _HotelFinderScreenState extends State<HotelFinderScreen> {
  final TextEditingController _controller = TextEditingController();
  MapController mapController = MapController();

  LatLng? searchedLocation;
  List<Marker> hotelMarkers = [];

  Future<void> searchLocation(String query) async {
    final url = Uri.parse(
        'https://nominatim.openstreetmap.org/search?q=$query&format=json');
    final response = await http
        .get(url, headers: {'User-Agent': 'FlutterHotelFinderApp/1.0'});

    if (response.statusCode == 200) {
      final results = jsonDecode(response.body);
      if (results.isNotEmpty) {
        final lat = double.parse(results[0]['lat']);
        final lon = double.parse(results[0]['lon']);
        setState(() {
          searchedLocation = LatLng(lat, lon);
          hotelMarkers = [
            Marker(
              width: 80,
              height: 80,
              point: LatLng(lat + 0.005, lon + 0.005),
              child: const Icon(Icons.hotel, color: Colors.blue, size: 40),
            ),
            Marker(
              width: 80,
              height: 80,
              point: LatLng(lat - 0.005, lon - 0.005),
              child: const Icon(Icons.hotel, color: Colors.red, size: 40),
            ),
          ];
          mapController.move(searchedLocation!, 14.0);
        });
      }
    } else {
      print('Failed to fetch location data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hotel Finder (Mock)'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Enter any location...',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      searchLocation(_controller.text);
                    }
                  },
                ),
                border: const OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: FlutterMap(
              mapController: mapController,
              options: MapOptions(
                center: LatLng(20.5937, 78.9629), // Default India center
                zoom: 5.0,
              ),
              children: [
                TileLayer(
                  urlTemplate:
                      "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                  subdomains: const ['a', 'b', 'c'],
                ),
                MarkerLayer(
                  markers: hotelMarkers,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
