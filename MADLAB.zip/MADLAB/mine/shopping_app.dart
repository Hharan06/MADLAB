import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Shopping App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    ElectronicsScreen(),
    HomeDecorationScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final List<String> _titles = [
    "Electronics",
    "Home Decoration",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_titles[_selectedIndex])),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.devices), label: 'Electronics'),
          BottomNavigationBarItem(icon: Icon(Icons.chair), label: 'Home Decor'),
        ],
      ),
    );
  }
}

class ElectronicsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(leading: Icon(Icons.phone_android), title: Text('Smartphone')),
        ListTile(leading: Icon(Icons.laptop), title: Text('Laptop')),
        ListTile(leading: Icon(Icons.tv), title: Text('Television')),
        ListTile(leading: Icon(Icons.headphones), title: Text('Headphones')),
      ],
    );
  }
}

class HomeDecorationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(leading: Icon(Icons.chair), title: Text('Chair')),
        ListTile(leading: Icon(Icons.bed), title: Text('Bed')),
        ListTile(leading: Icon(Icons.lamp), title: Text('Lamp')),
        ListTile(leading: Icon(Icons.villa), title: Text('Wall Art')),
      ],
    );
  }
}
