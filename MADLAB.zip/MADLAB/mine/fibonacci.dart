import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Fibonacci",
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: Fibonacci(),
    );
  }
}

class Fibonacci extends StatefulWidget {
  const Fibonacci({super.key});

  @override
  State<Fibonacci> createState() => _FibonacciState();
}

class _FibonacciState extends State<Fibonacci> {
  TextEditingController _numberController = TextEditingController();
  String result = "";

  void generateFibonacci() {
    setState(() {
      int? number = int.tryParse(_numberController.text);
      if (number == null || number < 0) {
        result = "Enter a valid number";
      } else {
        List<int> Sequence = [];
        for (int a = 0, b = 1, i = 0; i < number; i++) {
          Sequence.add(a);
          b = a + (a = b);
        }

        result = Sequence.join(" ,");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fibonacci Sequence"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            decoration: InputDecoration(
              labelText: "Enter a number",
            ),
            controller: _numberController,
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(onPressed: generateFibonacci, child: Text("Generate")),
          Text('Sequence: $result'),
        ],
      ),
    );
  }
}
