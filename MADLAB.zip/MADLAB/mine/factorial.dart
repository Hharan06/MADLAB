import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Factorial",
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: Factorial(),
    );
  }
}

class Factorial extends StatefulWidget {
  const Factorial({super.key});

  @override
  State<Factorial> createState() => _FactorialState();
}

class _FactorialState extends State<Factorial> {
  TextEditingController _numberController = TextEditingController();
  String _result = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Factorial"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            decoration: InputDecoration(
              labelText: "Enter a number",
            ),
            controller: _numberController,
          ),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  int? number = int.tryParse(_numberController.text);
                  int factorial = checkFactorial(number!);

                  _result = "$number! = $factorial";
                });
              },
              child: Text("Factorial")),
          Text(
            _result,
          )
        ],
      ),
    );
  }
}

int checkFactorial(int number) {
  if (number == 0 || number == 1) {
    return 1;
  } else {
    return number * checkFactorial(number - 1);
  }
}
