import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Animated Ball',
      home: AnimatedBall(),
    );
  }
}

class AnimatedBall extends StatefulWidget {
  @override
  _AnimatedBallState createState() => _AnimatedBallState();
}

class _AnimatedBallState extends State<AnimatedBall>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool isPlaying = false;
  double speed = 1.0;
  Color ballColor = Colors.red;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(seconds: 2))
          ..addListener(() => setState(() {}));
    _animation = Tween(begin: 0.0, end: 200.0)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  void toggleAnimation() {
    if (isPlaying) {
      _controller.stop();
    } else {
      _controller.repeat(reverse: true);
    }
    setState(() => isPlaying = !isPlaying);
  }

  void updateSpeed(double value) {
    setState(() {
      speed = value;
      _controller.duration = Duration(milliseconds: (2000 ~/ speed));
      if (isPlaying) _controller.repeat(reverse: true);
    });
  }

  void changeColor(String? color) {
    setState(() {
      ballColor = {
        'Red': Colors.red,
        'Blue': Colors.blue,
        'Green': Colors.green,
      }[color]!;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Animated Ball')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            child: Center(
              child: Container(
                margin: EdgeInsets.only(left: _animation.value),
                width: 50,
                height: 50,
                decoration:
                    BoxDecoration(color: ballColor, shape: BoxShape.circle),
              ),
            ),
          ),
          Slider(
            value: speed,
            min: 0.5,
            max: 3.0,
            divisions: 5,
            label: speed.toStringAsFixed(1),
            onChanged: updateSpeed,
          ),
          DropdownButton<String>(
            value: ballColor == Colors.red
                ? 'Red'
                : ballColor == Colors.blue
                    ? 'Blue'
                    : 'Green',
            onChanged: changeColor,
            items: ['Red', 'Blue', 'Green']
                .map((color) =>
                    DropdownMenuItem(value: color, child: Text(color)))
                .toList(),
          ),
          ElevatedButton(
            onPressed: toggleAnimation,
            child: Text(isPlaying ? 'Stop' : 'Start'),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
