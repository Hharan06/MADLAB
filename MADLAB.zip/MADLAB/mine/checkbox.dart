import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "BMI",
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: BMI(),
    );
  }
}

class BMI extends StatefulWidget {
  const BMI({super.key});

  @override
  State<BMI> createState() => _BMIState();
}

class _BMIState extends State<BMI> {
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  bool isMale = true;
  String userInputs = "";
  double result = 0;

  void calculateBMI() {
    setState(() {
      double? weight = double.tryParse(_weightController.text);
      double? height = double.tryParse(_heightController.text);

      if (weight == null || height == null || height == 0) {
        result = 0;
        return;
      }

      userInputs =
          "Weight: $weight, Height: $height, Gender: ${isMale ? 'Male' : 'Female'}";

      int valuebasedongender = isMale ? 100 : 150;

      result = (weight / pow(height, 2)) * valuebasedongender;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI"),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter weight (kg)"),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Enter height (m)"),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Checkbox(
                  value: isMale,
                  onChanged: (value) {
                    setState(() {
                      isMale = value!;
                    });
                  },
                ),
                Text("Male"),
              ],
            ),
            ElevatedButton(onPressed: calculateBMI, child: Text("Calculate")),
            SizedBox(height: 10),
            Text(userInputs),
            Text("BMI: $result"),
          ],
        ),
      ),
    );
  }
}
