import "package:flutter/material.dart";

void main() {
  runApp(TodoApp());
}

class TodoApp extends StatelessWidget {
  const TodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Todo App",
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: TodoScreen(),
    );
  }
}

class Todo {
  String title;
  bool done;
  Todo(this.title, {this.done = false});
}

class TodoScreen extends StatefulWidget {
  const TodoScreen({super.key});

  @override
  State<TodoScreen> createState() => _TodoScreenState();
}

class _TodoScreenState extends State<TodoScreen> {
  List<Todo> tasks = [];

  void showTaskDialog({Todo? task, int? index}) {
    TextEditingController controller =
        TextEditingController(text: task != null ? task.title : '');

    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text(task == null ? "Add Task" : "Edit Task"),
              content: TextField(
                controller: controller,
                decoration: InputDecoration(hintText: "Task name"),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text("Cancel")),
                ElevatedButton(
                    onPressed: () {
                      String text = controller.text.trim();

                      setState(() {
                        if (index != null) {
                          tasks[index].title = text;
                        } else {
                          tasks.add(Todo(text));
                        }
                      });

                      Navigator.pop(context);
                    },
                    child: Text("Save")),
              ],
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Todo App"),
      ),
      body: tasks.isEmpty
          ? Center(child: Text("No task available"))
          : ListView.builder(
              itemCount: tasks.length,
              itemBuilder: (_, i) => ListTile(
                leading: Checkbox(
                  value: tasks[i].done,
                  onChanged: (_) =>
                      setState(() => tasks[i].done = !tasks[i].done),
                ),
                title: Text(
                  tasks[i].title,
                  style: TextStyle(
                      decoration:
                          tasks[i].done ? TextDecoration.lineThrough : null),
                ),
                trailing: IconButton(
                    onPressed: () => setState(() {
                          tasks.removeAt(i);
                        }),
                    icon: Icon(Icons.delete)),
                onTap: () => showTaskDialog(task: tasks[i], index: i),
              ),
            ),
      floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add), onPressed: () => showTaskDialog()),
    );
  }
} 
