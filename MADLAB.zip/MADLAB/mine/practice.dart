import 'package:flutter/material.dart';
import 'dart:math';

import 'package:intl/intl.dart';

void main() {
  runApp(BMIApp());
}

class BMIApp extends StatelessWidget {
  const BMIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "BMI",
      debugShowCheckedModeBanner: false,
      home: BMIScreen(),
    );
  }
}

class BMIScreen extends StatefulWidget {
  const BMIScreen({super.key});

  @override
  State<BMIScreen> createState() => _BMIScreenState();
}

class _BMIScreenState extends State<BMIScreen> {
  final TextEditingController name = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  String _selectedGender = "Male";
  String userInputs = "";
  double result = 0.0;

  DateTime? checkingDate;
  int? daysremaining;

  TimeOfDay? selectedTime;
  int? timeremaining;

  void calculateBMI() {
    setState(() {
      String? user = name.text.trim();
      double? weight = double.tryParse(_weightController.text);
      double? height = double.tryParse(_heightController.text);

      userInputs = "Name: $user, Weight: $weight, Height: $height";

      int valuebasedongender = 1;

      switch (_selectedGender) {
        case "Male":
          valuebasedongender = 100;
          break;
        case "Female":
          valuebasedongender = 20;
          break;
        default:
          valuebasedongender = 1;
          break;
      }

      result = (weight! / pow(height!, 2)) * valuebasedongender;
    });
  }

  Future<void> selectDate(BuildContext context) async {
    DateTime? pickdate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime(2101));
    setState(() {
      checkingDate = pickdate;
      daysremaining = pickdate.difference(DateTime.now()).inDays;
    });
  }

  Future<void> selectTime(BuildContext context) async {
    TimeOfDay? pickTime =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());

    final now = DateTime.now();
  
    final selectedDateTime = DateTime(
      now.year,
      now.month,
      now.day,
      pickTime!.hour,
      pickTime.minute,
    );

    setState(() {
      selectedTime = pickTime;
      timeremaining = selectedDateTime.difference(DateTime.now()).inMinutes;
    });
  }

  @override
  Widget build(BuildContext context) {
    String formattedDate = checkingDate != null
        ? DateFormat("yyyy-MM-dd").format(checkingDate!)
        : "Select a Date";

    return Scaffold(
      appBar: AppBar(
        title: Text("BMI"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: name,
            decoration: InputDecoration(labelText: "Name"),
          ),
          SizedBox(height: 10),
          TextField(
            controller: _weightController,
            decoration: InputDecoration(labelText: "Weight"),
          ),
          SizedBox(height: 10),
          TextField(
            controller: _heightController,
            decoration: InputDecoration(labelText: "Height"),
          ),
          SizedBox(height: 10),
          DropdownButton(
              value: _selectedGender,
              items: ["Male", "Female"]
                  .map((e) => DropdownMenuItem(
                        child: Text(e),
                        value: e,
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedGender = value!;
                });
              }),
          ElevatedButton(onPressed: calculateBMI, child: Text("Calculate")),
          Text(userInputs),
          Text("BMI: $result"),
          ElevatedButton(
              onPressed: () => selectDate(context), child: Text(formattedDate)),
          Text("Remaining Days: $daysremaining"),
          ElevatedButton(
              onPressed: () => selectTime(context),
              child: Text(selectedTime != null
                  ? selectedTime!.format(context)
                  : "Select time")),
          Text("Remaining Minutes: $timeremaining"),
        ],
      ),
    );
  }
}
