import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(ArmstrongCheckerApp());
}

class ArmstrongCheckerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Armstrong Number Checker',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ArmstrongChecker(),
    );
  }
}

class ArmstrongChecker extends StatefulWidget {
  @override
  _ArmstrongCheckerState createState() => _ArmstrongCheckerState();
}

class _ArmstrongCheckerState extends State<ArmstrongChecker> {
  final TextEditingController _numberController = TextEditingController();
  String _result = "";

  void _checkArmstrong() {
    setState(() {
      int? number = int.tryParse(_numberController.text);
      if (number == null || number < 0) {
        _result = "Invalid Input";
        return;
      }

      int sum = 0, temp = number, power = number.toString().length;
      while (temp > 0) {
        int digit = temp % 10;
        sum += pow(digit, power).toInt(); // Explicitly casting num to int
        temp ~/= 10;
      }

      _result = (sum == number)
          ? "$number is an Armstrong Number"
          : "$number is Not an Armstrong Number";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Armstrong Number Checker'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _numberController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter a Number',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _checkArmstrong,
              child: Text('Check Armstrong'),
            ),
            SizedBox(height: 16),
            Text(
              _result,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
