import 'package:flutter/material.dart';

void main() {
  runApp(PetCareApp());
}

class PetCareApp extends StatelessWidget {
  const PetCareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Pet Care Management",
      theme: ThemeData(primarySwatch: Colors.green),
      debugShowCheckedModeBanner: false,
      home: PetCareScreen(),
    );
  }
}

class Pet {
  String name;
  String breed;
  DateTime vaccinationDate;

  Pet(this.name, this.breed, this.vaccinationDate);
}

class PetCareScreen extends StatefulWidget {
  const PetCareScreen({super.key});

  @override
  State<PetCareScreen> createState() => _PetCareScreenState();
}

class _PetCareScreenState extends State<PetCareScreen> {
  List<Pet> pets = [];

  Future<void> showPetDialog({Pet? pet, int? index}) async {
    TextEditingController nameController =
        TextEditingController(text: pet?.name ?? '');
    TextEditingController breedController =
        TextEditingController(text: pet?.breed ?? '');
    DateTime selectedDate = pet?.vaccinationDate ?? DateTime.now();

    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: Text(pet == null ? "Add Pet" : "Edit Pet"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(hintText: "Pet Name"),
              ),
              TextField(
                controller: breedController,
                decoration: InputDecoration(hintText: "Pet Breed"),
              ),
              SizedBox(height: 10),
              Text(
                  "Vaccination Date: ${selectedDate.toLocal().toString().split(' ')[0]}"),
              ElevatedButton(
                onPressed: () async {
                  DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: selectedDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime(2101),
                  );
                  if (picked != null) {
                    setStateDialog(() {
                      selectedDate = picked;
                    });
                  }
                },
                child: Text("Select Date"),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context), child: Text("Cancel")),
            ElevatedButton(
              onPressed: () {
                String name = nameController.text.trim();
                String breed = breedController.text.trim();

                if (name.isNotEmpty && breed.isNotEmpty) {
                  setState(() {
                    if (index != null) {
                      pets[index] = Pet(name, breed, selectedDate);
                    } else {
                      pets.add(Pet(name, breed, selectedDate));
                    }
                  });
                  Navigator.pop(context);
                }
              },
              child: Text("Save"),
            ),
          ],
        ),
      ),
    );
  }

  String remainingDays(DateTime date) {
    int days = date.difference(DateTime.now()).inDays;
    return days >= 0 ? "$days days left" : "Overdue";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pet Care Management"),
      ),
      body: pets.isEmpty
          ? Center(child: Text("No pets added"))
          : ListView.builder(
              itemCount: pets.length,
              itemBuilder: (_, i) => ListTile(
                title: Text("${pets[i].name} (${pets[i].breed})"),
                subtitle: Text(
                  "Vaccination: ${pets[i].vaccinationDate.toLocal().toString().split(' ')[0]} • ${remainingDays(pets[i].vaccinationDate)}",
                ),
                trailing: IconButton(
                    onPressed: () => setState(() {
                          pets.removeAt(i);
                        }),
                    icon: Icon(Icons.delete)),
                onTap: () => showPetDialog(pet: pets[i], index: i),
              ),
            ),
      floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add), onPressed: () => showPetDialog()),
    );
  }
}
